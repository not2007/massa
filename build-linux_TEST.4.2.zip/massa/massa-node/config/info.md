This folder contains all node-related user config data that should be backed up.
The node needs read and write access to it.
